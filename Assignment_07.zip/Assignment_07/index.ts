// import inquirer from "inquirer";
// const answer = await inquirer.prompt([{
//     type: 'input',
//     name:'name',
//     message: 'What is your name?'},
// {
//     type:'number',
//     name:'age',
//     message:'Enter your age:'
// },
// {
//     type:'list',
//     name:'gender',
//     message:'Enter your gender?',
//     choices:['Male','Female','Prefer not to say']
// }]);
// console.log("Your name is " + answer.name +",Your age is "+ answer.age + ". Your gender is " +answer.gender);

import inquirer from "inquirer";
var operator=await inquirer.prompt([{
type:'number',
name:'Num1',
message:'Enter a num1: ',

},
{
    type:'number',
    name:'Num2',
    message:'Enter num2: ',
},
{
    type:'list',
    name:'operate',
    message:'select The operation',
    choices:['Add','Sub','Mul','Div','Mod']
}])
var result;
switch (operator.operate){
    case'Add':
    result=operator.Num1+operator.Num2;
    break;
    case'Sub':
    result=operator.Num1-operator.Num2;
    break;
    case'Mul':
    result=operator.Num1*operator.Num2;
    break;
    case'Div':
    result=operator.Num1/operator.Num2;
    break;
    case'Mod':
    result=operator.Num1%operator.Num2
    break;
}
console.log("The Answer is ",result);