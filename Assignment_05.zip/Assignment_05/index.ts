// Question 1: Use filter to remove negative numbers from an array.

const numbers1 = [-1, 2, -3, 4, -5];
const filteredNumbers1 = numbers1.filter((num) => num >= 0);
console.log(filteredNumbers1); // Output: [2, 4]

// Question 2: Use map to multiply each number by 2.

const numbers2 = [1, 2, 3, 4, 5];
const doubledNumbers2 = numbers2.map((num) => num * 2);
console.log(doubledNumbers2); // Output: [2, 4, 6, 8, 10]

// Question 3: Use filter to get fruits with more than 5 characters.

const fruits3 = ["apple", "banana", "cherry", "date", "grape"];
const longFruits3 = fruits3.filter((fruit) => fruit.length > 5);
console.log(longFruits3); // Output: ["banana", "cherry"]

// Question 4: Use map and filter to get squares of even numbers.

const numbers4 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
const squaresOfEvenNumbers4 = numbers4.filter((num) => num % 2 === 0).map((num) => num * num);
console.log(squaresOfEvenNumbers4); // Output: [4, 16, 36, 64, 100]

// Question 5: Use map to convert temperatures from Celsius to Fahrenheit.

const celsiusTemperatures5 = [0, 10, 20, 30, 40];
const fahrenheitTemperatures5 = celsiusTemperatures5.map((tempCelsius) => (tempCelsius * 9/5) + 32);
console.log(fahrenheitTemperatures5); // Output: [32, 50, 68, 86, 104]

// Question 6: Use map and filter to get doubled values of odd numbers.

const numbers6 = [3, 6, 9, 12, 15, 18];
const doubledOddNumbers6 = numbers6.filter((num) => num % 2 !== 0).map((num) => num * 2);
console.log(doubledOddNumbers6); // Output: [6, 18, 30]

// Question 7: Use forEach to log names with exclamation marks.

const names7 = ["Alice", "Bob", "Charlie", "David", "Emily"];
names7.forEach((name) => console.log(name + "!")); // Output: // Alice! // Bob! // Charlie! // David! // Emily!