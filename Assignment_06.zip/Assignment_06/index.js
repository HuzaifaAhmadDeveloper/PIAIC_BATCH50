"use strict";
// Question 2: Personal Message
const personName2 = "Eric";
console.log(`Hello ${personName2}, would you like to learn some Python today?`);
// Question 3: Name Cases
const personName3 = "Huzaifa Ahmad";
console.log(`Original Name: ${personName3}`);
console.log(`Lowercase: ${personName3.toLowerCase()}`);
console.log(`Uppercase: ${personName3.toUpperCase()}`);
console.log(`Titlecase: ${personName3.split(' ').map(word => word[0].toUpperCase() + word.slice(1).toLowerCase()).join(' ')}`);
// Question 4: Famous Quote
const quote4 = "A person who never made a mistake never tried anything new.";
const author4 = "Albert Einstein";
console.log(`${author4} once said, "${quote4}"`);
// Question 5: Famous Quote 2
const famous_person5 = "Albert Einstein";
const message5 = `${famous_person5} once said, "${quote4}"`;
console.log(message5);
// Question 6: Stripping Names
const name6 = "\t   Huzaifa Ahmad \n";
console.log(`Name with Whitespace: "${name6}"`);
console.log(`Name after Stripping Whitespace: "${name6.trim()}"`);
// Question 7: Number Eight
console.log(5 + 3);
console.log(10 - 2);
console.log(4 * 2);
console.log(16 / 2);
// Question 9: Favorite Number
const favoriteNumber9 = 4;
console.log(`My favorite number is ${favoriteNumber9}`);
// Question 11: Names
const names11 = ["Ali", "Bilal", "Ahad", "Zulfiqar", "Fassi"];
for (const name of names11) {
    console.log(name);
}
// Question 12: Greetings
for (const name of names11) {
    console.log(`Hello ${name}, have a great day!`);
}
// Question 13: Your Own Array
const transportation13 = ["car", "motorcycle", "bicycle", "bus"];
for (const vehicle of transportation13) {
    console.log(`I would like to own a ${vehicle}.`);
}
// Question 14: Guest List
const dinnerGuests14 = ["Ahmad", "Maria", "Isaac"];
for (const guest of dinnerGuests14) {
    console.log(`Dear ${guest}, you are invited to dinner.`);
}
// Question 15: Changing Guest List
console.log(`${dinnerGuests14[1]} can't make it.`);
dinnerGuests14[1] = "Zia ur rehman";
for (const guest of dinnerGuests14) {
    console.log(`Dear ${guest}, you are still invited to dinner.`);
}
// Question 16: More Guests
console.log("We found a bigger dinner table!");
dinnerGuests14.unshift("Galileo Galilei");
dinnerGuests14.splice(2, 0, "Stephen Hawking");
dinnerGuests14.push("Nikola Tesla");
for (const guest of dinnerGuests14) {
    console.log(`Dear ${guest}, you are invited to dinner.`);
}
// Question 17: Shrinking Guest List
console.log("We can only invite two people for dinner.");
while (dinnerGuests14.length > 2) {
    const removedGuest = dinnerGuests14.pop();
    console.log(`Sorry ${removedGuest}, you can't be invited.`);
}
for (const guest of dinnerGuests14) {
    console.log(`Dear ${guest}, you are still invited to dinner.`);
}
console.log("The guest list is now empty:", dinnerGuests14);
// Question 18: Seeing the World
const places18 = ["Paris", "Tokyo", "New York", "Rome", "Sydney"];
console.log("Original Order:", places18.join(", "));
console.log("Alphabetical Order:", places18.slice().sort().join(", "));
console.log("Original Order (still):", places18.join(", "));
console.log("Reverse Alphabetical Order:", places18.slice().sort().reverse().join(", "));
console.log("Original Order (still):", places18.join(", "));
console.log("Reversed Order:", places18.reverse().join(", "));
console.log("Original Order (again):", places18.join(", "));
console.log("Alphabetical Order (sorted):", places18.slice().sort().join(", "));
console.log("Reverse Alphabetical Order (sorted):", places18.slice().sort().reverse().join(", "));
// Question 19: Dinner Guests
console.log(`Number of people invited to dinner: ${dinnerGuests14.length}`);
// Question 20: Arrays
const favoriteFruits20 = ["apple", "banana", "mango"];
for (const fruit of favoriteFruits20) {
    console.log(`I love ${fruit}s.`);
}
// Question 21: Objects
const favoriteColors21 = {
    "Ali": "blue",
    "Bilal": "red",
    "Fassi": "green"
};
console.log(`Ali favorite color is ${favoriteColors21["Ali"]}`);
console.log(`Bilal favorite color is ${favoriteColors21["Bilal"]}`);
console.log(`Fassi favorite color is ${favoriteColors21["Fassi"]}`);
// Question 22: Intentional Error
// Uncommenting the next line will produce an index error
// console.log(favoriteFruits20[3]);
// Question 23: Conditional Tests
const car23 = 'safari';
console.log(`Is car == 'safari'? I predict ${car23 == 'safari'}`);
// Question 30: Magicians
function show_magicians(magicians) {
    for (const magician of magicians) {
        console.log(magician);
    }
}
const magicians30 = ["Imran", "Ali", "fassi & Niaz"];
show_magicians(magicians30);
// Question 31: Great Magicians
function make_great(magicians) {
    const greatMagicians = [];
    for (const magician of magicians) {
        greatMagicians.push(`the Great ${magician}`);
    }
    return greatMagicians;
}
const greatMagicians31 = make_great(magicians30);
show_magicians(greatMagicians31);
// Question 32: Unchanged Magicians
const originalMagicians32 = ["Zia", "Hamza", "Haroon"];
const greatMagicians32 = make_great([...originalMagicians32]);
show_magicians(originalMagicians32);
show_magicians(greatMagicians32);
// Question 33: Ordinal Numbers
const numbers33 = [1, 2, 3, 4, 5, 6, 7, 8, 9];
for (const num of numbers33) {
    let suffix = "th";
    if (num === 1) {
        suffix = "st";
    }
    else if (num === 2) {
        suffix = "nd";
    }
    else if (num === 3) {
        suffix = "rd";
    }
    console.log(`${num}${suffix}`);
}
// Question 34: Pizzas
const favoritePizzas34 = ["Fajita", "Malae boti", "kabab special"];
for (const pizza of favoritePizzas34) {
    console.log(`I like ${pizza} pizza.`);
}
// Question 35: Animals
const commonCharacteristic35 = "mammals";
const animals35 = ["dog", "cat", "elephant"];
for (const animal of animals35) {
    console.log(`${animal} are ${commonCharacteristic35}.`);
}
// Question 36: T-Shirt
function make_shirt(size, message) {
    console.log(`Shirt Size: ${size}, Message: "${message}"`);
}
make_shirt("Large", "Hello, World!");
// Question 37: Large Shirts
function make_shirt_default(size = "Large", message = "I love TypeScript") {
    console.log(`Shirt Size: ${size}, Message: "${message}"`);
}
make_shirt_default(); // Large shirt with default message
make_shirt_default("Medium"); // Medium shirt with default message
make_shirt_default("Small", "Custom message"); // Small shirt with custom message
// Question 38: Cities
function describe_city(city, country = "Unknown") {
    console.log(`${city} is in ${country}.`);
}
describe_city("Karachi", "Pakistan");
describe_city("Paris", "France");
describe_city("New York"); // City with default country
// Question 39: City Names
function city_country(city, country) {
    return `${city}, ${country}`;
}
const city1 = city_country("Lahore", "Pakistan");
const city2 = city_country("Tokyo", "Japan");
const city3 = city_country("Sydney", "Australia");
console.log(city1);
console.log(city2);
console.log(city3);
/* Question 40: Album

function make_album(artist: string, title: string, tracks?: number) {
  const album = {
    artist: artist,
    title: title,
  };
  if (tracks) {
    album['tracks'] = tracks;
  }
  return album;
}

const album1 = make_album("The Beatles", "Abbey Road", 17);
const album2 = make_album("Pink Floyd", "The Wall");
console.log(album1);
console.log(album2);
*/
// Question 41: Magicians
const magicians41 = ["David Copperfield", "Harry Houdini", "Penn & Teller"];
function show_magicians41(magicians) {
    for (const magician of magicians) {
        console.log(magician);
    }
}
show_magicians41(magicians41);
// Question 42: Great Magicians
function make_great42(magicians) {
    const greatMagicians = [];
    for (const magician of magicians) {
        greatMagicians.push(`the Great ${magician}`);
    }
    return greatMagicians;
}
const greatMagicians42 = make_great42(magicians41);
show_magicians41(greatMagicians42);
// Question 43: Unchanged Magicians
const originalMagicians43 = ["Chris", "David", "Derren"];
const greatMagicians43 = make_great42([...originalMagicians43]);
show_magicians41(originalMagicians43);
show_magicians41(greatMagicians43);
// Question 44: Sandwiches
function orderSandwich(...items) {
    console.log(`You ordered a sandwich with ${items.join(', ')}.`);
}
orderSandwich("lettuce", "tomato", "cheese");
orderSandwich("turkey", "bacon");
orderSandwich("ham");
// Question 45: Cars
function carInfo(manufacturer, model, ...options) {
    const car = {
        manufacturer,
        model,
    };
    for (const option of options) {
        const [key, value] = option.split('=');
        car[key] = value;
    }
    return car;
}
const carInfo1 = carInfo("Toyota", "Camry", "color=blue", "year=2022");
console.log(carInfo1);
const carInfo2 = carInfo("Honda", "Civic");
console.log(carInfo2);
